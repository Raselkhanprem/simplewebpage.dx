var splide = new Splide( '.splide', {
    type   : 'loop',
    padding: '5rem',
  } );
  
  splide.mount();


  const slide = document.createElement( 'li' );
slide.classList.add( 'splide__slide' );
add( slide );

remove( 0 );


// Removes slides at 0 and 1:
remove( [ 0, 1 ] );


// Removes slides by a selector:
remove( '.is-visible' );


// Removes slides by a predicate function:
remove( Slide => Slide.index % 2 === 0 );


var splide = new Splide( '.splide' );
splide.mount();